<?php
print "<svg width=900 height=900>
        <circle cx=375 cy=375 r=150 fill=rgb(255,0,0) style=\"mix-blend-mode:screen;\"></circle>
        <circle cx=525 cy=375 r=150 fill=rgb(0,255,0) style=\"mix-blend-mode:screen;\"></circle>
        <circle cx=450 cy=505 r=150 fill=rgb(0,0,255) style=\"mix-blend-mode:screen;\"></circle>
    </svg>";
?>