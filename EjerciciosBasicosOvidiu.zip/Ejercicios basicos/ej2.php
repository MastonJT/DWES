<?php
$rand=rand(16,72);
print "<p style=\"font-size:$rand;\">Hola Mundo!</p>"
?>