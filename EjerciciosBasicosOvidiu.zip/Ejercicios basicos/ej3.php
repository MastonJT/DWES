<?php
$rand=rand(0,10);
print '<p style="font-size:'.($rand*3).';">'.$rand.'</p>';
?>