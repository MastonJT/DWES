<?php
    $nombre=$_GET['nombre'];
echo "Su nombre es {$nombre}";