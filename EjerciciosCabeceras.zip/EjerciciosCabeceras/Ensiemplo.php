<?php
header("Location: http://www.example.com");
echo "Pantumaca";